'''from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
import mysql.connector

router = APIRouter()

# MySQL DB connection config
db_config = {
    "host": "localhost",
    "user": "root",
    "password": "Viveka@9164",
    "database": "feedbackdb"
}

# Pydantic model for login request
class LoginRequest(BaseModel):
    username: str
    password: str

# Login route
@router.post("/login")
def login(request: LoginRequest):
    conn = mysql.connector.connect(**db_config)
    cursor = conn.cursor(dictionary=True)

    query = "SELECT * FROM users WHERE username=%s AND password=%s"
    cursor.execute(query, (request.username, request.password))
    user = cursor.fetchone()

    cursor.close()
    conn.close()

    if user:
        # Avoid sending password back
        user.pop("password", None)
        return {"status": "success", "user": user}
    else:
        raise HTTPException(status_code=401, detail="Invalid credentials") '''
from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
import mysql.connector
import os

router = APIRouter()

# Use environment variables for DB config (with default fallback)
port_env = os.getenv("DB_PORT", "3306")
try:
    db_port = int(port_env)
except ValueError:
    print(f"Invalid DB_PORT value: {port_env}, using 3306")
    db_port = 3306

db_config = {
    "host": os.getenv("DB_HOST", "localhost"),
    "user": os.getenv("DB_USER", "root"),
    "password": os.getenv("DB_PASSWORD", ""),
    "database": os.getenv("DB_NAME", "feedbackdb"),
    "port": db_port
}

# Pydantic model for login request
class LoginRequest(BaseModel):
    username: str
    password: str

# Login route
@router.post("/login")
def login(request: LoginRequest):
    try:
        conn = mysql.connector.connect(**db_config)
        cursor = conn.cursor(dictionary=True)

        query = "SELECT * FROM users WHERE username=%s AND password=%s"
        cursor.execute(query, (request.username, request.password))
        user = cursor.fetchone()

        cursor.close()
        conn.close()

        if user:
            user.pop("password", None)  # Avoid sending password
            return {"status": "success", "user": user}
        else:
            raise HTTPException(status_code=401, detail="Invalid credentials")
    
    except mysql.connector.Error as err:
        raise HTTPException(status_code=500, detail=str(err))
