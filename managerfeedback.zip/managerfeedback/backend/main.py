from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

# Importing routers from separate modules
from login import router as login_router
from feedback import router as feedback_router

# Create FastAPI app instance
app = FastAPI()

# CORS middleware to allow frontend communication
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # You can restrict this to your React frontend URL in production
    allow_methods=["*"],
    allow_headers=["*"],
)

# Include route modules (login and feedback)
app.include_router(login_router)
app.include_router(feedback_router)
