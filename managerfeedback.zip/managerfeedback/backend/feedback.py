'''from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
import mysql.connector

router = APIRouter()

# MySQL connection config
db_config = {
    "host": "localhost",
    "user": "root",
    "password": "Viveka@9164",
    "database": "feedbackdb"
}

# Feedback schema for adding
class Feedback(BaseModel):
    manager_username: str
    employee_username: str
    message: str
    strengths: str
    improvements: str
    sentiment: str

# Separate schema for updating (no manager/employee)
class FeedbackUpdate(BaseModel):
    message: str
    strengths: str
    improvements: str
    sentiment: str

# Add feedback entry
@router.post("/feedback")
def add_feedback(fb: Feedback):
    conn = mysql.connector.connect(**db_config)
    cursor = conn.cursor()

    # Check if employee exists
    cursor.execute("SELECT * FROM users WHERE username=%s AND role='employee'", (fb.employee_username,))
    if not cursor.fetchone():
        raise HTTPException(status_code=404, detail="Employee not found")

    # Insert feedback
    query = """
        INSERT INTO feedback (manager_username, employee_username, message, strengths, improvements, sentiment)
        VALUES (%s, %s, %s, %s, %s, %s)
    """
    values = (
        fb.manager_username,
        fb.employee_username,
        fb.message,
        fb.strengths,
        fb.improvements,
        fb.sentiment
    )
    cursor.execute(query, values)
    conn.commit()

    cursor.close()
    conn.close()
    return {"status": "Feedback submitted"}

# Get feedback for a specific employee
@router.get("/feedback/{employee_username}")
def get_feedback(employee_username: str):
    conn = mysql.connector.connect(**db_config)
    cursor = conn.cursor(dictionary=True)

    query = "SELECT * FROM feedback WHERE employee_username=%s ORDER BY timestamp DESC"
    cursor.execute(query, (employee_username,))
    feedbacks = cursor.fetchall()

    cursor.close()
    conn.close()
    return feedbacks

# Delete feedback
@router.delete("/feedback/delete/{feedback_id}")
def delete_feedback(feedback_id: int):
    conn = mysql.connector.connect(**db_config)
    cursor = conn.cursor()
    cursor.execute("DELETE FROM feedback WHERE id = %s", (feedback_id,))
    conn.commit()
    cursor.close()
    conn.close()
    return {"status": "deleted"}

# Update feedback (uses FeedbackUpdate model)
@router.put("/feedback/update/{feedback_id}")
def update_feedback(feedback_id: int, fb: FeedbackUpdate):
    conn = mysql.connector.connect(**db_config)
    cursor = conn.cursor()
    sql = """
        UPDATE feedback 
        SET message=%s, strengths=%s, improvements=%s, sentiment=%s
        WHERE id=%s
    """
    cursor.execute(sql, (fb.message, fb.strengths, fb.improvements, fb.sentiment, feedback_id))
    conn.commit()
    cursor.close()
    conn.close()
    return {"status": "updated"}

# Acknowledge feedback
@router.put("/feedback/acknowledge/{id}")
def acknowledge_feedback(id: int):
    conn = mysql.connector.connect(**db_config)
    cursor = conn.cursor()
    cursor.execute("UPDATE feedback SET acknowledged=TRUE WHERE id=%s", (id,))
    conn.commit()
    cursor.close()
    conn.close()
    return {"status": "Acknowledged"}'''

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
import mysql.connector
import os

router = APIRouter()

# MySQL connection config using environment variables
db_config = {
    "host": os.getenv("DB_HOST", "localhost"),
    "user": os.getenv("DB_USER", "root"),
    "password": os.getenv("DB_PASSWORD", "Viveka@9164"),
    "database": os.getenv("DB_NAME", "feedbackdb"),
    "port": int(os.getenv("DB_PORT", "3306"))
}

class Feedback(BaseModel):
    manager_username: str
    employee_username: str
    message: str
    strengths: str
    improvements: str
    sentiment: str

class FeedbackUpdate(BaseModel):
    message: str
    strengths: str
    improvements: str
    sentiment: str

@router.post("/feedback")
def add_feedback(fb: Feedback):
    conn = mysql.connector.connect(**db_config)
    cursor = conn.cursor()

    cursor.execute("SELECT * FROM users WHERE username=%s AND role='employee'", (fb.employee_username,))
    if not cursor.fetchone():
        raise HTTPException(status_code=404, detail="Employee not found")

    cursor.execute(
        """
        INSERT INTO feedback (manager_username, employee_username, message, strengths, improvements, sentiment)
        VALUES (%s, %s, %s, %s, %s, %s)
        """,
        (fb.manager_username, fb.employee_username, fb.message, fb.strengths, fb.improvements, fb.sentiment)
    )
    conn.commit()
    cursor.close()
    conn.close()
    return {"status": "Feedback submitted"}

@router.get("/feedback/{employee_username}")
def get_feedback(employee_username: str):
    conn = mysql.connector.connect(**db_config)
    cursor = conn.cursor(dictionary=True)

    cursor.execute("SELECT * FROM feedback WHERE employee_username=%s ORDER BY timestamp DESC", (employee_username,))
    feedbacks = cursor.fetchall()
    cursor.close()
    conn.close()
    return feedbacks

@router.delete("/feedback/delete/{feedback_id}")
def delete_feedback(feedback_id: int):
    conn = mysql.connector.connect(**db_config)
    cursor = conn.cursor()
    cursor.execute("DELETE FROM feedback WHERE id = %s", (feedback_id,))
    conn.commit()
    cursor.close()
    conn.close()
    return {"status": "deleted"}

@router.put("/feedback/update/{feedback_id}")
def update_feedback(feedback_id: int, fb: FeedbackUpdate):
    conn = mysql.connector.connect(**db_config)
    cursor = conn.cursor()
    cursor.execute(
        """
        UPDATE feedback 
        SET message=%s, strengths=%s, improvements=%s, sentiment=%s
        WHERE id=%s
        """,
        (fb.message, fb.strengths, fb.improvements, fb.sentiment, feedback_id)
    )
    conn.commit()
    cursor.close()
    conn.close()
    return {"status": "updated"}

@router.put("/feedback/acknowledge/{id}")
def acknowledge_feedback(id: int):
    conn = mysql.connector.connect(**db_config)
    cursor = conn.cursor()
    cursor.execute("UPDATE feedback SET acknowledged=TRUE WHERE id=%s", (id,))
    conn.commit()
    cursor.close()
    conn.close()
    return {"status": "Acknowledged"}
'''you need run this if are in windows for mysql connected 

docker-compose -p managerfeedback up --build   

docker run -d `
  -e DB_HOST=host.docker.internal `
  -e DB_USER=root `
  -e DB_PASSWORD=Viveka@9164 `
  -e DB_NAME=feedbackdb `
  -e DB_PORT=3306 `
  -p 8000:8000 `
  --name managerfeedback-backend `
  managerfeedback-backend


'''