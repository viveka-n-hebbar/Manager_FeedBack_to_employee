import React, { useState, useEffect } from 'react';
import axios from 'axios';
import Login from './Login';
import './App.css';

function App() {
  const [user, setUser] = useState(null);
  const [selectedEmployee, setSelectedEmployee] = useState('');
  const [feedbackList, setFeedbackList] = useState([]);
  const [formData, setFormData] = useState({
    message: '',
    strengths: '',
    improvements: '',
    sentiment: 'positive'
  });
  const [editId, setEditId] = useState(null);
  const [editData, setEditData] = useState({});
  const [refresh, setRefresh] = useState(0);
  const [loggedOut, setLoggedOut] = useState(false);

  useEffect(() => {
    if (user?.role === 'manager' && selectedEmployee) {
      axios.get(`http://localhost:8000/feedback/${selectedEmployee}`)
        .then(res => setFeedbackList(res.data));
    } else if (user?.role === 'employee') {
      axios.get(`http://localhost:8000/feedback/${user.username}`)
        .then(res => setFeedbackList(res.data));
    }
  }, [selectedEmployee, refresh, user]);

  const handleSubmitFeedback = async (e) => {
    e.preventDefault();
    await axios.post('http://localhost:8000/feedback', {
      manager_username: user.username,
      employee_username: selectedEmployee,
      ...formData
    });
    setFormData({ message: '', strengths: '', improvements: '', sentiment: 'positive' });
    setRefresh(r => r + 1);
  };

  const handleDelete = async (id) => {
    await axios.delete(`http://localhost:8000/feedback/delete/${id}`);
    setRefresh(r => r + 1);
  };

  const handleEdit = (item) => {
    setEditId(item.id);
    setEditData({
      message: item.message,
      strengths: item.strengths,
      improvements: item.improvements,
      sentiment: item.sentiment
    });
  };

  const handleUpdate = async (e) => {
    e.preventDefault();
    await axios.put(`http://localhost:8000/feedback/update/${editId}`, editData);
    setEditId(null);
    setRefresh(r => r + 1);
  };

  const handleAcknowledge = async (id) => {
    await axios.put(`http://localhost:8000/feedback/acknowledge/${id}`);
    setRefresh(r => r + 1);
  };

  const handleLogout = () => {
    setUser(null);
    setSelectedEmployee('');
    setFeedbackList([]);
    setLoggedOut(true);
  };

  if (!user) {
    return (
      <div className="app-container">
        {loggedOut && <p style={{ color: 'green', textAlign: 'center' }}>✅ You have logged out successfully.</p>}
        <Login onLogin={setUser} />
      </div>
    );
  }

  return (
    <div className="app-container">
      <h1>Feedback System</h1>
      <p>Welcome, {user.username}</p>
      <div style={{ textAlign: 'center', marginBottom: '20px' }}>
        <button onClick={handleLogout}>Logout</button>
      </div>

      {user.role === 'manager' && (
        <>
          <form onSubmit={(e) => { e.preventDefault(); setRefresh(r => r + 1); }}>
            <input
              value={selectedEmployee}
              onChange={(e) => setSelectedEmployee(e.target.value)}
              placeholder="Search employee by username"
              required
            />
            <button type="submit">Search</button>
          </form>

          {selectedEmployee && (
            <form onSubmit={handleSubmitFeedback}>
              <textarea
                placeholder="Message"
                value={formData.message}
                onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                required
              />
              <input
                placeholder="Strengths"
                value={formData.strengths}
                onChange={(e) => setFormData({ ...formData, strengths: e.target.value })}
              />
              <input
                placeholder="Areas to improve"
                value={formData.improvements}
                onChange={(e) => setFormData({ ...formData, improvements: e.target.value })}
              />
              <select
                value={formData.sentiment}
                onChange={(e) => setFormData({ ...formData, sentiment: e.target.value })}
              >
                <option value="positive">Positive</option>
                <option value="neutral">Neutral</option>
                <option value="negative">Negative</option>
              </select>
              <button type="submit">Submit Feedback</button>
            </form>
          )}
        </>
      )}

      <h3>{user.role === 'employee' ? "My Feedback" : `Feedback for ${selectedEmployee}`}</h3>

      <ul>
        {feedbackList.length === 0 && <li>No feedback yet.</li>}
        {feedbackList.map((f) => (
          <li key={f.id}>
            {editId === f.id ? (
              <form onSubmit={handleUpdate}>
                <textarea
                  value={editData.message}
                  onChange={(e) => setEditData({ ...editData, message: e.target.value })}
                />
                <input
                  value={editData.strengths}
                  onChange={(e) => setEditData({ ...editData, strengths: e.target.value })}
                />
                <input
                  value={editData.improvements}
                  onChange={(e) => setEditData({ ...editData, improvements: e.target.value })}
                />
                <select
                  value={editData.sentiment}
                  onChange={(e) => setEditData({ ...editData, sentiment: e.target.value })}
                >
                  <option value="positive">Positive</option>
                  <option value="neutral">Neutral</option>
                  <option value="negative">Negative</option>
                </select>
                <button type="submit">Update</button>
                <button type="button" onClick={() => setEditId(null)}>Cancel</button>
              </form>
            ) : (
              <>
                <p><strong>Message:</strong> {f.message}</p>
                <p><strong>Strengths:</strong> {f.strengths}</p>
                <p><strong>Improvements:</strong> {f.improvements}</p>
                <p><strong>Sentiment:</strong> {f.sentiment}</p>
                <p><strong>Acknowledged:</strong> {f.acknowledged ? '✅ Yes' : '❌ No'}</p>

                {user.role === 'manager' && (
                  <>
                    <button onClick={() => handleEdit(f)}>Edit</button>
                    <button onClick={() => handleDelete(f.id)}>Delete</button>
                  </>
                )}

                {user.role === 'employee' && !f.acknowledged && (
                  <button onClick={() => handleAcknowledge(f.id)}>Acknowledge</button>
                )}
              </>
            )}
          </li>
        ))}
      </ul>
    </div>
  );
}

export default App;
